#!/usr/bin/env bash
echo migrate
