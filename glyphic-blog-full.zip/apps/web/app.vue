<template><div>stub</div></template>
