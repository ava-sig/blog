**CODENAME:** GOV-CORE-006
**GLYPH NAME:** Conflict Resolution

...
